from django.shortcuts import render
import datetime
from datetime import timedelta

def landing(request):
    return render(
        request,
        'main/landing.html'
    )

def main(request):
    return render(
        request,
        'main/main.html'
    )

def demo(request):
    return render(request, 'demo.html')


def contact(request):
    return render(
        request,'contact.html')

def about(request):
    return render(
        request,'about.html')

def service(request):
    return render(request, 'service.html')

def profile(request):
    return render(request, 'profile.html')
